<footer class="py-3">
    <div class="container">
        @include('layouts.footers.nav')
    </div>
</footer>