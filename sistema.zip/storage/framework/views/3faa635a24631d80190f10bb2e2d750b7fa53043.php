<?php $__env->startSection('content'); ?>
<div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
    <div class="container-fluid">
        <div class="header-body">
            <!-- Card stats -->
            <div class="row">
                <div class="col-xl-12 col-lg-12">
                    <div class="card card-stats mb-4 mb-xl-0">
                        <div class="card-body">
                            <div class="row">
                                <div class="col">
                                    <h5 class="card-title text-uppercase text-muted mb-0">Aplicativos</h5>
                                <span class="h2 font-weight-bold mb-0"><?php echo e(count($aplicativos)); ?></span>
                                </div>
                                <div class="col-auto">
                                    <div class="icon icon-shape bg-danger text-white rounded-circle shadow">
                                        <i class="ni ni-app"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid mt--7">
    <div class="header-body">
        <div class="row">
            <div class="col">
                <div class="card shadow">
                    <div class="card-header border-0">
                        <div class="row align-items-center">
                            <div class="col">
                                <h3 class="mb-0">Gerenciar Aplicativos</h3>
                            </div>
                            <div class="col text-right">
                                <td>
                                                   
                                              
                                    <form action="<?php echo e(route('aplicativos.create')); ?>">
                                        
                                        <button type="submit" class="btn btn-success">Cadastrar Novo</button>
                                    </form>
                                </td>
                              
                            </div>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table align-items-center table-flush">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col" width="100">Imagem</th>
                                    <th scope="col">Nome</th>
                                    <th scope="col">Package</th>
                                    <th scope="col">Link p/ Download</th>
                                    <th scope="col" width="100">Ações</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $__currentLoopData = $aplicativos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aplicativo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td>
                                        <?php if($aplicativo->image): ?>
                                            <img src="<?php echo e(url("storage/{$aplicativo->image}")); ?>" alt="<?php echo e($aplicativo->nome); ?>" style="max-width: 100px;">
                                        <?php endif; ?> 
                                    </td>
                                    <td><?php echo e($aplicativo->nome); ?></td>
                                    <td><?php echo e($aplicativo->package); ?></td>
                                    <td><?php echo e($aplicativo->link); ?></td>

                                    <td>
                                        <form action="<?php echo e(route('aplicativos.edit', $aplicativo->id)); ?>">
                                           <?php echo csrf_field(); ?>
                                           
                                           <button type="submit" class="btn btn-success btn-sm">Editar</button>
                                       </form>
                                       <br>
                                       <form action="<?php echo e(route('aplicativos.destroy', $aplicativo->id)); ?>" method="post">
                                           <?php echo csrf_field(); ?>
                                           <?php echo method_field('DELETE'); ?>
                                           <button type="submit" class="btn btn-danger btn-sm">Deletar</button>
                                       </form>
                                   </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>    
                    </div> 
                </div>
            </div>
        </div>
    </div>
</div>
<br>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jocimarl/Documentos/Projetos/forteplay-projetos/painel/resources/views/dashboard.blade.php ENDPATH**/ ?>