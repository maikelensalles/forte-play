<?php $__env->startSection('content'); ?>
<div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
    <div class="container-fluid"> 
        <div class="header-body">
            <div class="card shadow">
                <div class="card-header border-0">
                    <div class="p-4 bg-secondary">
                        <h1>Cadastrar Novo Aplicativo</h1> 
                        <form action="<?php echo e(route('aplicativos.store')); ?>" method="post" enctype="multipart/form-data" class="form">
                            <?php echo $__env->make('admin.pages.aplicativos.reuses.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => __('Cadastrar Produto')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jocimarl/Documentos/Projetos/forteplay-projetos/forte-play/resources/views/admin/pages/aplicativos/create.blade.php ENDPATH**/ ?>