            

            <?php $__env->startSection('content'); ?> 
            <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">
            
                <div class="container-fluid">
                    <a type="button" class="btn btn-success" style="margin-bottom: 15px" href="/users" >
                        <i class="fa fa-refresh"></i>
                        Recarregar
                    </a>
                    <div class="header-body">
                        <div class="row">
                            <div class="col">
                                <div class="card shadow">
                                    <div class="card-header border-0">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h3 class="mb-0">Gestão de Usuários</h3>
                                            </div>
                                            <div class="col text-right">
                                                <td>
                                                   
                                                   
                                                   
                                               </td>
                                              
                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table class="table align-items-center table-flush">
                                            <thead class="thead-light">
                                                <tr>
                                                    <th>Nome</th>
                                                    <th>ID Acesso</th>
                                                    <th>Telefone</th>
                                                    <th>Aplicativo Usado</th>
                                                    <th>Hora</th>
                                                    <th>Data</th>
                                                    
                                                </tr>
                                            </thead>
            
                                            <tbody>
                                                <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($c->nome); ?></td>
                                                    <td><?php echo e($c->login); ?></td>
                                                    <td><a href="https://api.whatsapp.com/send?phone=55<?php echo e($c->telefone); ?>"><?php echo e($c->telefone); ?></a></td>
                                                    <td><?php echo e($c->aplicativo); ?></td>
                                                    <td><?php echo e(date( 'H:i' , strtotime($c->created_at))); ?></td>
                                                    <td><?php echo e(date( 'd/m/Y' , strtotime($c->created_at))); ?></td>
                                                        
                                                    </tr> 
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        
                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/jocimarl/Documentos/Projetos/forteplay-projetos/forte-play/resources/views/users/index.blade.php ENDPATH**/ ?>