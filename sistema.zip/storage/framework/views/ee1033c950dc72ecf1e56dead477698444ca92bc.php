<nav class="navbar navbar-top navbar-horizontal navbar-expand-md navbar-dark">
    <div class="container px-4">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('argon')); ?>/img/fortplay-white.png" />
        </a>
        <!-- 
        <div class="collapse navbar-collapse" id="navbar-collapse-main">
            <div class="navbar-collapse-header d-md-none">
                <div class="row">
                    <div class="col-6 collapse-brand">
                        <a href="<?php echo e(route('home')); ?>">
                            <img src="<?php echo e(asset('argon')); ?>/img/logo-home-side.png">
                        </a>
                    </div>
                    <div class="col-6 collapse-close">
                        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbar-collapse-main" aria-controls="sidenav-main" aria-expanded="false" aria-label="Toggle sidenav">
                            <span></span>
                            <span></span>
                        </button>
                    </div>
                </div>
            </div>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a class="nav-link nav-link-icon" href="<?php echo e(route('login')); ?>">
                        <i class="ni ni-key-25"></i>
                        <span class="nav-link-inner--text"><?php echo e(__('Login')); ?></span>
                    </a>
                </li>                   
            </ul> -->
        </div>
    </div>
</nav><?php /**PATH /home/jocimarl/Documentos/Projetos/forteplay-projetos/forte-play/resources/views/layouts/navbars/navs/guest.blade.php ENDPATH**/ ?>