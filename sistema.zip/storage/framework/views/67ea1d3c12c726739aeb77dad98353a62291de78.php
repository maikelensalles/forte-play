<?php echo $__env->make('admin.includes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo csrf_field(); ?>
<div class="form-group">
    <input type="text" class="form-control" name="nome" placeholder="Nome:" value="<?php echo e($aplicativo->nome ?? old('nome')); ?>">
</div>
<div class="form-group">
    <input type="text" name="package" class="form-control" placeholder="Pacote:"  value="<?php echo e($aplicativo->package ?? old('package')); ?>">
</div> 
<div class="form-group">
    <input type="text" name="link" class="form-control" placeholder="Link:"  value="<?php echo e($aplicativo->link?? old('link')); ?>">
</div>

<div class="form-group">
    <input type="file" name="image" class="form-control">
</div>
<div class="form-group">
    <button type="submit" class="btn btn-primary">Enviar</button>
</div><?php /**PATH /home/jocimarl/Documentos/Projetos/forteplay-projetos/forte-play/resources/views/admin/pages/aplicativos/reuses/form.blade.php ENDPATH**/ ?>